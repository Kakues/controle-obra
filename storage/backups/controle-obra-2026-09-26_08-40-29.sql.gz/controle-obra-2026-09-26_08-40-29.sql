-- MySQL dump 10.13  Distrib 8.4.11, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diaria_historicos`
--

DROP TABLE IF EXISTS `diaria_historicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diaria_historicos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `funcionario_id` bigint unsigned NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `vigente_desde` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `diaria_historicos_funcionario_id_vigente_desde_unique` (`funcionario_id`,`vigente_desde`),
  CONSTRAINT `diaria_historicos_funcionario_id_foreign` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diaria_historicos`
--

LOCK TABLES `diaria_historicos` WRITE;
/*!40000 ALTER TABLE `diaria_historicos` DISABLE KEYS */;
INSERT INTO `diaria_historicos` VALUES (5,5,150.00,'2026-08-10','2026-08-10 00:10:01','2026-08-10 00:10:01'),(6,6,250.00,'2026-08-10','2026-08-10 00:10:46','2026-08-10 00:10:46'),(7,7,250.00,'2026-08-10','2026-08-10 00:11:20','2026-08-10 00:11:20'),(8,8,170.00,'2026-08-10','2026-08-10 00:12:45','2026-08-10 00:12:45'),(9,9,110.00,'2026-08-10','2026-08-10 00:13:38','2026-08-10 00:13:38'),(10,10,110.00,'2026-08-10','2026-08-10 00:14:07','2026-08-10 00:14:07'),(11,11,120.00,'2026-08-10','2026-08-10 00:14:46','2026-08-10 00:14:46'),(12,13,120.00,'2026-08-10','2026-08-10 20:40:11','2026-08-10 20:40:11'),(13,9,130.00,'2026-08-17','2026-08-17 21:33:39','2026-08-17 21:33:39'),(14,8,190.00,'2026-08-17','2026-08-17 21:33:50','2026-08-17 21:33:50'),(16,15,200.00,'2026-08-26','2026-08-26 21:03:10','2026-08-26 21:03:10'),(17,16,200.00,'2026-08-26','2026-08-26 21:03:23','2026-08-26 21:03:23'),(18,18,110.00,'2026-08-28','2026-08-28 20:10:55','2026-08-28 20:10:55'),(19,19,200.00,'2026-08-28','2026-08-28 20:50:53','2026-08-28 20:56:22'),(20,20,130.00,'2026-08-28','2026-08-28 20:51:20','2026-08-28 20:51:20'),(21,21,200.00,'2026-08-28','2026-08-28 21:01:56','2026-08-28 21:01:56'),(22,22,150.00,'2026-08-28','2026-08-28 21:02:08','2026-08-28 21:02:08'),(23,23,200.00,'2026-09-02','2026-09-02 21:01:50','2026-09-02 21:01:50'),(24,24,120.00,'2026-09-09','2026-09-09 08:56:58','2026-09-09 08:56:58'),(25,25,270.00,'2026-09-11','2026-09-11 21:11:30','2026-09-11 21:11:30'),(26,18,120.00,'2026-09-21','2026-09-21 20:41:49','2026-09-21 20:41:49');
/*!40000 ALTER TABLE `diaria_historicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionarios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `regime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'diaria',
  `superior_id` bigint unsigned DEFAULT NULL,
  `telefone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diaria_atual` decimal(10,2) NOT NULL DEFAULT '0.00',
  `locomocao_tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'nenhuma',
  `locomocao_valor` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `funcionarios_superior_id_foreign` (`superior_id`),
  CONSTRAINT `funcionarios_superior_id_foreign` FOREIGN KEY (`superior_id`) REFERENCES `funcionarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionarios`
--

LOCK TABLES `funcionarios` WRITE;
/*!40000 ALTER TABLE `funcionarios` DISABLE KEYS */;
INSERT INTO `funcionarios` VALUES (5,'Kaiky Calixto','diaria',NULL,NULL,150.00,'gasolina',50.00,1,NULL,'2026-08-10 00:10:01','2026-09-04 21:59:40'),(6,'Willame Martins','diaria',NULL,NULL,250.00,'gasolina',50.00,1,NULL,'2026-08-10 00:10:46','2026-09-04 22:02:54'),(7,'Wellington Matias','diaria',NULL,NULL,250.00,'nenhuma',0.00,1,NULL,'2026-08-10 00:11:20','2026-09-04 22:02:33'),(8,'Gleison Antonio','diaria',NULL,NULL,190.00,'onibus',4.50,1,NULL,'2026-08-10 00:12:45','2026-09-04 21:58:29'),(9,'Deyvison','diaria',NULL,NULL,130.00,'nenhuma',0.00,0,NULL,'2026-08-10 00:13:38','2026-08-25 18:55:16'),(10,'Filipe','diaria',NULL,NULL,110.00,'onibus',4.50,0,NULL,'2026-08-10 00:14:07','2026-08-25 18:55:24'),(11,'Lucas Basilio','diaria',NULL,NULL,120.00,'nenhuma',0.00,1,NULL,'2026-08-10 00:14:46','2026-09-04 22:01:48'),(12,'Julio Cesar','empreita',NULL,NULL,0.00,'nenhuma',0.00,1,NULL,'2026-08-10 00:23:58','2026-09-04 21:59:32'),(13,'Jefferson','diaria',NULL,NULL,120.00,'nenhuma',0.00,0,NULL,'2026-08-10 20:40:11','2026-08-17 21:34:16'),(15,'Somario','diaria',NULL,NULL,200.00,'nenhuma',0.00,0,NULL,'2026-08-26 21:03:10','2026-09-02 21:01:41'),(16,'Cleber Batista','diaria',NULL,NULL,200.00,'nenhuma',0.00,1,NULL,'2026-08-26 21:03:23','2026-09-04 21:58:39'),(17,'Daniel Ribeiro','empreita',NULL,NULL,0.00,'nenhuma',0.00,1,NULL,'2026-08-28 20:05:22','2026-09-11 21:29:19'),(18,'Victor Brendo','diaria',NULL,NULL,120.00,'onibus',4.50,1,NULL,'2026-08-28 20:10:55','2026-09-21 20:41:49'),(19,'Leandro Moreira','diaria',NULL,NULL,200.00,'nenhuma',0.00,1,NULL,'2026-08-28 20:50:53','2026-09-04 21:59:52'),(20,'Rei','diaria',19,NULL,130.00,'nenhuma',0.00,0,NULL,'2026-08-28 20:51:20','2026-09-02 21:01:58'),(21,'Alonso','diaria',19,NULL,200.00,'nenhuma',0.00,1,NULL,'2026-08-28 21:01:56','2026-08-28 21:01:56'),(22,'Fernando','diaria',19,NULL,150.00,'nenhuma',0.00,1,NULL,'2026-08-28 21:02:08','2026-08-28 21:02:08'),(23,'Roberto Batista','diaria',NULL,NULL,200.00,'nenhuma',0.00,1,NULL,'2026-09-02 21:01:50','2026-09-04 22:02:03'),(24,'Giovanni Guerra','diaria',NULL,NULL,120.00,'nenhuma',0.00,1,NULL,'2026-09-09 08:56:58','2026-09-11 21:13:00'),(25,'Valdecir Ferreira','diaria',NULL,NULL,270.00,'nenhuma',0.00,1,'Serralheiro','2026-09-11 21:11:30','2026-09-11 21:11:30');
/*!40000 ALTER TABLE `funcionarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lancamentos`
--

DROP TABLE IF EXISTS `lancamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lancamentos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `funcionario_id` bigint unsigned NOT NULL,
  `periodo_pagamento_id` bigint unsigned DEFAULT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `data` date NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrado_por` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lancamentos_funcionario_id_foreign` (`funcionario_id`),
  KEY `lancamentos_periodo_pagamento_id_foreign` (`periodo_pagamento_id`),
  KEY `lancamentos_registrado_por_foreign` (`registrado_por`),
  CONSTRAINT `lancamentos_funcionario_id_foreign` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lancamentos_periodo_pagamento_id_foreign` FOREIGN KEY (`periodo_pagamento_id`) REFERENCES `periodo_pagamentos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `lancamentos_registrado_por_foreign` FOREIGN KEY (`registrado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lancamentos`
--

LOCK TABLES `lancamentos` WRITE;
/*!40000 ALTER TABLE `lancamentos` DISABLE KEYS */;
INSERT INTO `lancamentos` VALUES (1,9,3,'bonus',100.00,'2026-08-14','+ 20 de cada diária (coloquei errado',3,'2026-08-14 20:19:56','2026-08-14 20:19:56'),(2,8,3,'bonus',100.00,'2026-08-14','+ 20 por diária (coloquei errado',3,'2026-08-14 20:21:10','2026-08-14 20:21:10'),(3,12,3,'empreita',1200.00,'2026-08-14','Diária 200 + 40 de gasolina',3,'2026-08-14 20:24:08','2026-08-14 20:24:46'),(6,5,4,'bonus',60.00,'2026-08-21','pagamentos',3,'2026-08-21 20:21:23','2026-08-21 20:21:23'),(7,12,4,'empreita',950.00,'2026-08-21','pagamento de 4 dias 200 diaria + 50gasolina dia',3,'2026-08-21 21:14:18','2026-08-21 21:14:18'),(9,8,5,'desconto',20.00,'2026-08-26','pegou 20 reais com Kaiky',3,'2026-08-26 21:05:29','2026-08-26 21:05:29'),(12,17,5,'empreita',1500.00,'2026-08-28',NULL,3,'2026-08-28 20:05:38','2026-08-28 20:05:38'),(13,12,5,'empreita',1250.00,'2026-08-28',NULL,3,'2026-08-28 20:05:54','2026-08-28 20:05:54'),(14,8,5,'desconto',50.00,'2026-08-28','emprestou 50 pra lucas',3,'2026-08-28 20:09:20','2026-08-28 20:09:20'),(15,5,5,'bonus',20.00,'2026-08-28','emprestou 20 pra gleison',3,'2026-08-28 20:09:56','2026-08-28 20:09:56'),(16,11,5,'bonus',50.00,'2026-08-28','emprestou 50 pra gleison',3,'2026-08-28 20:10:09','2026-08-28 20:10:09'),(17,18,5,'bonus',4.50,'2026-08-28','passagem quinta feira (voltamos)',3,'2026-08-28 20:12:01','2026-08-28 20:12:01'),(18,8,5,'bonus',4.50,'2026-08-28','passagem quinta feira (voltamos)',3,'2026-08-28 20:12:36','2026-08-28 20:12:36'),(19,8,5,'desconto',20.00,'2026-08-28','pegou 20 com meu pai',3,'2026-08-28 20:12:53','2026-08-28 20:12:53'),(20,6,5,'bonus',50.00,'2026-08-28','gasolina quinta que voltamos',3,'2026-08-28 20:14:41','2026-08-28 20:14:41'),(21,5,5,'bonus',60.00,'2026-08-28','fez os pagamentos',3,'2026-08-28 21:09:20','2026-08-28 21:09:20'),(22,5,5,'bonus',50.00,'2026-08-28','gasolina voltamos quinta',3,'2026-08-28 21:15:27','2026-08-28 21:15:27'),(23,12,6,'empreita',1250.00,'2026-09-04',NULL,3,'2026-09-04 21:44:11','2026-09-04 21:45:08'),(24,12,7,'empreita',1000.00,'2026-09-11',NULL,3,'2026-09-11 21:05:18','2026-09-11 21:05:18'),(25,5,7,'bonus',120.00,'2026-09-11','pagamento 2 semanas',3,'2026-09-11 21:05:47','2026-09-11 21:05:47'),(26,17,7,'empreita',922.00,'2026-09-11',NULL,3,'2026-09-11 21:08:17','2026-09-11 21:08:17'),(27,5,8,'bonus',60.00,'2026-09-18','pagamento semana 3 setembro',3,'2026-09-15 21:20:42','2026-09-15 21:20:42'),(28,12,8,'empreita',1250.00,'2026-09-18',NULL,3,'2026-09-18 21:30:24','2026-09-18 21:30:24'),(29,16,8,'bonus',50.00,'2026-09-18','gasolina da semana',3,'2026-09-18 21:31:15','2026-09-18 21:31:15'),(30,18,8,'adiantamento',140.00,'2026-09-18',NULL,3,'2026-09-18 21:32:09','2026-09-18 21:32:09'),(31,5,9,'bonus',60.00,'2026-09-25','pagamento',3,'2026-09-25 20:21:35','2026-09-25 20:21:35'),(32,12,9,'empreita',1250.00,'2026-09-25',NULL,3,'2026-09-25 20:46:09','2026-09-25 20:46:09');
/*!40000 ALTER TABLE `lancamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_08_04_235150_create_obras_table',1),(5,'2026_08_04_235152_create_funcionarios_table',1),(6,'2026_08_04_235153_create_diaria_historicos_table',1),(7,'2026_08_04_235154_create_periodo_pagamentos_table',1),(8,'2026_08_04_235155_create_presencas_table',1),(9,'2026_08_04_235156_create_lancamentos_table',1),(10,'2026_08_05_202643_add_locomocao_to_funcionarios_and_presencas_tables',1),(11,'2026_08_06_002143_create_pagamento_funcionarios_table',1),(12,'2026_08_09_115335_add_role_to_users_table',2),(13,'2026_08_10_001944_add_regime_to_funcionarios_table',3),(14,'2026_08_28_201000_add_superior_id_to_funcionarios_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `obras`
--

DROP TABLE IF EXISTS `obras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obras` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endereco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativa` tinyint(1) NOT NULL DEFAULT '1',
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obras`
--

LOCK TABLES `obras` WRITE;
/*!40000 ALTER TABLE `obras` DISABLE KEYS */;
INSERT INTO `obras` VALUES (2,'Luan','Versalles',1,NULL,'2026-08-10 20:39:03','2026-08-10 20:39:03'),(3,'Gilma',NULL,1,NULL,'2026-08-10 20:39:16','2026-08-10 20:39:16'),(4,'Jardel','Versales',1,NULL,'2026-08-10 20:39:42','2026-08-10 20:39:42'),(5,'Nao fixa',NULL,1,'Colocar qual obra foi mexida no dia','2026-08-18 20:25:06','2026-08-18 20:25:06'),(6,'Ana julia',NULL,1,NULL,'2026-09-02 21:02:29','2026-09-02 21:02:29'),(8,'Guilherme',NULL,1,NULL,'2026-09-02 21:02:50','2026-09-02 21:02:50');
/*!40000 ALTER TABLE `obras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagamento_funcionarios`
--

DROP TABLE IF EXISTS `pagamento_funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagamento_funcionarios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `periodo_pagamento_id` bigint unsigned NOT NULL,
  `funcionario_id` bigint unsigned NOT NULL,
  `forma` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `data_pagamento` date DEFAULT NULL,
  `observacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrado_por` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pag_func_periodo_unique` (`periodo_pagamento_id`,`funcionario_id`),
  KEY `pagamento_funcionarios_funcionario_id_foreign` (`funcionario_id`),
  KEY `pagamento_funcionarios_registrado_por_foreign` (`registrado_por`),
  CONSTRAINT `pagamento_funcionarios_funcionario_id_foreign` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pagamento_funcionarios_periodo_pagamento_id_foreign` FOREIGN KEY (`periodo_pagamento_id`) REFERENCES `periodo_pagamentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pagamento_funcionarios_registrado_por_foreign` FOREIGN KEY (`registrado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagamento_funcionarios`
--

LOCK TABLES `pagamento_funcionarios` WRITE;
/*!40000 ALTER TABLE `pagamento_funcionarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagamento_funcionarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodo_pagamentos`
--

DROP TABLE IF EXISTS `periodo_pagamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `periodo_pagamentos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_inicio` date NOT NULL,
  `data_fim` date NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aberto',
  `fechado_em` timestamp NULL DEFAULT NULL,
  `pago_em` timestamp NULL DEFAULT NULL,
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodo_pagamentos`
--

LOCK TABLES `periodo_pagamentos` WRITE;
/*!40000 ALTER TABLE `periodo_pagamentos` DISABLE KEYS */;
INSERT INTO `periodo_pagamentos` VALUES (3,'Segunda semana agosto','2026-08-10','2026-08-15','fechado','2026-08-21 20:21:56',NULL,NULL,'2026-08-10 20:41:04','2026-08-21 20:21:56'),(4,'semana 3 agosto','2026-08-17','2026-08-22','fechado','2026-08-25 18:47:40',NULL,NULL,'2026-08-17 21:33:07','2026-08-25 18:47:40'),(5,'semana 4 agosto','2026-08-24','2026-08-29','fechado','2026-09-04 00:44:44',NULL,NULL,'2026-08-25 18:50:00','2026-09-04 00:44:44'),(6,'semana 1 setembro','2026-08-31','2026-09-05','fechado','2026-09-08 22:28:50',NULL,NULL,'2026-09-01 22:33:35','2026-09-08 22:28:50'),(7,'semana 2 setembro','2026-09-08','2026-09-12','fechado','2026-09-15 21:19:48',NULL,'segunda foi feriado','2026-09-08 22:29:18','2026-09-15 21:19:48'),(8,'semana 3 setembro','2026-09-14','2026-09-19','fechado','2026-09-21 20:40:17',NULL,NULL,'2026-09-15 21:17:01','2026-09-21 20:40:17'),(9,'semana 2 agosto','2026-09-21','2026-09-26','aberto',NULL,NULL,NULL,'2026-09-21 20:40:33','2026-09-21 20:40:33');
/*!40000 ALTER TABLE `periodo_pagamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presencas`
--

DROP TABLE IF EXISTS `presencas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `presencas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `funcionario_id` bigint unsigned NOT NULL,
  `obra_id` bigint unsigned NOT NULL,
  `data` date NOT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'integral',
  `valor_aplicado` decimal(10,2) NOT NULL,
  `locomocao_tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'nenhuma',
  `valor_locomocao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `observacao` text COLLATE utf8mb4_unicode_ci,
  `registrado_por` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `presencas_funcionario_id_data_unique` (`funcionario_id`,`data`),
  KEY `presencas_obra_id_foreign` (`obra_id`),
  KEY `presencas_registrado_por_foreign` (`registrado_por`),
  CONSTRAINT `presencas_funcionario_id_foreign` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `presencas_obra_id_foreign` FOREIGN KEY (`obra_id`) REFERENCES `obras` (`id`) ON DELETE CASCADE,
  CONSTRAINT `presencas_registrado_por_foreign` FOREIGN KEY (`registrado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presencas`
--

LOCK TABLES `presencas` WRITE;
/*!40000 ALTER TABLE `presencas` DISABLE KEYS */;
INSERT INTO `presencas` VALUES (20,9,2,'2026-08-10','integral',110.00,'nenhuma',0.00,NULL,3,'2026-08-10 20:43:21','2026-08-10 20:43:21'),(21,8,3,'2026-08-10','integral',170.00,'onibus',4.50,NULL,3,'2026-08-10 20:43:21','2026-08-10 20:43:21'),(22,13,4,'2026-08-10','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-10 20:43:21','2026-08-10 20:43:21'),(23,5,3,'2026-08-10','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-10 20:43:21','2026-08-10 20:43:21'),(24,11,2,'2026-08-10','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-10 20:43:21','2026-08-10 20:43:21'),(25,7,4,'2026-08-10','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-10 20:43:21','2026-08-10 20:43:21'),(26,6,3,'2026-08-10','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-10 20:43:21','2026-08-10 20:43:21'),(27,9,2,'2026-08-11','integral',110.00,'nenhuma',0.00,NULL,3,'2026-08-11 20:36:12','2026-08-11 20:36:12'),(28,8,3,'2026-08-11','integral',170.00,'onibus',4.50,NULL,3,'2026-08-11 20:36:12','2026-08-11 20:36:12'),(29,5,3,'2026-08-11','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-11 20:36:12','2026-08-11 20:36:12'),(30,11,2,'2026-08-11','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-11 20:36:12','2026-08-11 20:36:12'),(31,7,4,'2026-08-11','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-11 20:36:12','2026-08-11 20:36:12'),(32,6,3,'2026-08-11','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-11 20:36:12','2026-08-11 20:36:12'),(33,9,2,'2026-08-12','integral',110.00,'nenhuma',0.00,NULL,3,'2026-08-12 21:11:21','2026-08-12 21:11:21'),(34,8,3,'2026-08-12','integral',170.00,'onibus',4.50,NULL,3,'2026-08-12 21:11:21','2026-08-12 21:11:21'),(35,5,3,'2026-08-12','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-12 21:11:21','2026-08-12 21:11:21'),(36,11,3,'2026-08-12','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-12 21:11:21','2026-08-12 21:11:21'),(37,7,4,'2026-08-12','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-12 21:11:21','2026-08-12 21:11:21'),(38,6,3,'2026-08-12','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-12 21:11:21','2026-08-12 21:11:21'),(39,9,2,'2026-08-13','integral',110.00,'nenhuma',0.00,NULL,3,'2026-08-13 20:42:10','2026-08-13 20:42:10'),(40,8,4,'2026-08-13','integral',170.00,'onibus',4.50,NULL,3,'2026-08-13 20:42:10','2026-08-13 20:42:10'),(41,5,3,'2026-08-13','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-13 20:42:10','2026-08-13 20:42:10'),(42,7,4,'2026-08-13','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-13 20:42:10','2026-08-13 20:42:10'),(43,6,3,'2026-08-13','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-13 20:42:10','2026-08-13 20:42:10'),(44,9,2,'2026-08-14','integral',110.00,'nenhuma',0.00,NULL,3,'2026-08-14 20:17:42','2026-08-14 20:17:42'),(45,8,4,'2026-08-14','integral',170.00,'onibus',4.50,NULL,3,'2026-08-14 20:17:42','2026-08-14 20:17:42'),(46,5,3,'2026-08-14','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-14 20:17:42','2026-08-14 20:17:42'),(47,11,2,'2026-08-14','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-14 20:17:42','2026-08-14 20:17:42'),(48,7,4,'2026-08-14','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-14 20:17:42','2026-08-14 20:17:42'),(49,6,3,'2026-08-14','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-14 20:17:42','2026-08-14 20:17:42'),(50,9,4,'2026-08-17','integral',130.00,'nenhuma',0.00,NULL,3,'2026-08-18 20:21:35','2026-08-18 20:21:35'),(51,5,3,'2026-08-17','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-18 20:21:35','2026-08-18 20:21:35'),(52,11,4,'2026-08-17','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-18 20:21:35','2026-08-18 20:21:35'),(53,7,4,'2026-08-17','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-18 20:21:35','2026-08-18 20:21:35'),(54,6,3,'2026-08-17','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-18 20:21:35','2026-08-18 20:21:35'),(55,9,4,'2026-08-18','integral',130.00,'nenhuma',0.00,NULL,3,'2026-08-18 20:22:34','2026-08-18 20:22:34'),(56,8,3,'2026-08-18','integral',190.00,'onibus',4.50,NULL,3,'2026-08-18 20:22:34','2026-08-18 20:22:34'),(57,5,3,'2026-08-18','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-18 20:22:34','2026-08-18 20:22:34'),(58,11,2,'2026-08-18','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-18 20:22:34','2026-08-18 20:22:34'),(59,7,4,'2026-08-18','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-18 20:22:34','2026-08-18 20:22:34'),(60,6,3,'2026-08-18','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-18 20:22:34','2026-08-18 20:22:34'),(61,9,4,'2026-08-19','integral',130.00,'nenhuma',0.00,NULL,3,'2026-08-19 20:53:57','2026-08-19 20:53:57'),(62,8,3,'2026-08-19','integral',190.00,'onibus',4.50,NULL,3,'2026-08-19 20:53:57','2026-08-19 20:53:57'),(63,5,3,'2026-08-19','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-19 20:53:57','2026-08-19 20:53:57'),(64,11,2,'2026-08-19','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-19 20:53:57','2026-08-19 20:53:57'),(65,7,4,'2026-08-19','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-19 20:53:57','2026-08-19 20:53:57'),(66,6,3,'2026-08-19','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-19 20:53:57','2026-08-19 20:53:57'),(67,9,4,'2026-08-20','integral',130.00,'nenhuma',0.00,NULL,3,'2026-08-20 20:41:15','2026-08-20 20:41:15'),(68,8,3,'2026-08-20','integral',190.00,'onibus',4.50,NULL,3,'2026-08-20 20:41:15','2026-08-20 20:41:15'),(69,5,3,'2026-08-20','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-20 20:41:15','2026-08-20 20:41:15'),(70,11,2,'2026-08-20','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-20 20:41:15','2026-08-20 20:41:15'),(71,7,4,'2026-08-20','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-20 20:41:15','2026-08-20 20:41:15'),(72,6,3,'2026-08-20','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-20 20:41:15','2026-08-20 20:41:15'),(73,9,4,'2026-08-21','integral',130.00,'nenhuma',0.00,NULL,3,'2026-08-21 20:19:32','2026-08-21 20:19:32'),(74,8,3,'2026-08-21','integral',190.00,'onibus',4.50,NULL,3,'2026-08-21 20:19:32','2026-08-21 20:19:32'),(75,5,3,'2026-08-21','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-21 20:19:32','2026-08-21 20:19:32'),(76,11,2,'2026-08-21','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-21 20:19:32','2026-08-21 20:19:32'),(77,7,4,'2026-08-21','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-21 20:19:32','2026-08-21 20:19:32'),(78,6,3,'2026-08-21','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-21 20:19:32','2026-08-21 20:19:32'),(79,8,3,'2026-08-25','integral',190.00,'onibus',4.50,NULL,3,'2026-08-25 18:50:35','2026-08-25 18:50:35'),(80,5,3,'2026-08-25','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-25 18:50:35','2026-08-25 18:50:35'),(82,7,4,'2026-08-25','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-25 18:50:35','2026-08-25 18:54:10'),(83,6,3,'2026-08-25','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-25 18:50:35','2026-08-25 18:50:35'),(84,8,3,'2026-08-24','integral',190.00,'onibus',4.50,NULL,3,'2026-08-25 18:53:35','2026-08-25 18:53:35'),(85,5,3,'2026-08-24','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-25 18:53:35','2026-08-25 18:53:35'),(87,7,4,'2026-08-24','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-25 18:53:35','2026-08-25 18:53:35'),(88,6,3,'2026-08-24','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-25 18:53:35','2026-08-25 18:53:35'),(89,16,2,'2026-08-26','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-26 21:04:40','2026-08-26 21:04:40'),(90,8,3,'2026-08-26','integral',190.00,'onibus',4.50,NULL,3,'2026-08-26 21:04:40','2026-08-26 21:04:40'),(91,5,3,'2026-08-26','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-26 21:04:40','2026-08-26 21:04:40'),(93,11,2,'2026-08-26','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-26 21:04:40','2026-08-26 21:07:07'),(94,15,2,'2026-08-26','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-26 21:04:40','2026-08-26 21:04:40'),(95,7,4,'2026-08-26','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-26 21:04:40','2026-08-26 21:04:40'),(96,6,3,'2026-08-26','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-26 21:04:40','2026-08-26 21:04:40'),(97,16,2,'2026-08-24','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-26 21:04:57','2026-08-26 21:04:57'),(98,15,2,'2026-08-24','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-26 21:04:57','2026-08-26 21:04:57'),(99,16,2,'2026-08-25','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-26 21:05:04','2026-08-26 21:05:04'),(100,16,2,'2026-08-28','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 19:53:10','2026-08-28 19:53:10'),(101,8,3,'2026-08-28','integral',190.00,'onibus',4.50,NULL,3,'2026-08-28 19:53:10','2026-08-28 19:53:10'),(102,5,2,'2026-08-28','integral',150.00,'gasolina',50.00,NULL,3,'2026-08-28 19:53:10','2026-08-28 19:53:10'),(103,11,2,'2026-08-28','integral',120.00,'nenhuma',0.00,NULL,3,'2026-08-28 19:53:10','2026-08-28 19:53:10'),(104,15,2,'2026-08-28','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 19:53:10','2026-08-28 19:53:10'),(105,7,4,'2026-08-28','integral',250.00,'nenhuma',0.00,NULL,3,'2026-08-28 19:53:10','2026-08-28 19:53:10'),(106,6,3,'2026-08-28','integral',250.00,'gasolina',50.00,NULL,3,'2026-08-28 19:53:10','2026-08-28 19:53:10'),(108,16,2,'2026-08-27','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 20:07:06','2026-08-28 20:07:06'),(109,15,2,'2026-08-27','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 20:07:06','2026-08-28 20:07:06'),(110,18,3,'2026-08-28','integral',110.00,'onibus',4.50,NULL,3,'2026-08-28 20:11:33','2026-08-28 20:11:33'),(111,19,4,'2026-08-24','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:02:42','2026-08-28 21:02:42'),(112,19,4,'2026-08-25','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:03:21','2026-08-28 21:03:21'),(113,22,4,'2026-08-25','integral',150.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:03:21','2026-08-28 21:03:21'),(114,20,4,'2026-08-25','integral',130.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:03:21','2026-08-28 21:03:21'),(115,19,4,'2026-08-26','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:03:45','2026-08-28 21:03:45'),(116,21,4,'2026-08-26','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:03:45','2026-08-28 21:03:45'),(117,22,4,'2026-08-26','integral',150.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:03:45','2026-08-28 21:03:45'),(118,19,4,'2026-08-28','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:05:07','2026-08-28 21:05:07'),(119,21,4,'2026-08-28','integral',200.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:06:39','2026-08-28 21:06:39'),(120,22,4,'2026-08-28','integral',150.00,'nenhuma',0.00,NULL,3,'2026-08-28 21:07:13','2026-08-28 21:07:13'),(121,16,6,'2026-08-31','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:05:37'),(122,8,3,'2026-08-31','integral',190.00,'onibus',4.50,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(123,5,8,'2026-08-31','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(124,11,8,'2026-08-31','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(125,23,2,'2026-08-31','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(126,18,3,'2026-08-31','integral',110.00,'onibus',4.50,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(127,7,4,'2026-08-31','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(128,6,3,'2026-08-31','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(129,19,4,'2026-08-31','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(130,21,4,'2026-08-31','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(131,22,4,'2026-08-31','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:04:21','2026-09-02 21:04:21'),(132,16,6,'2026-09-01','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(133,8,3,'2026-09-01','integral',190.00,'onibus',4.50,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(134,5,3,'2026-09-01','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(135,11,8,'2026-09-01','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(136,23,6,'2026-09-01','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(137,18,3,'2026-09-01','integral',110.00,'onibus',4.50,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(138,7,4,'2026-09-01','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(139,6,3,'2026-09-01','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(140,19,4,'2026-09-01','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(141,21,4,'2026-09-01','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(142,22,4,'2026-09-01','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:05:22','2026-09-02 21:05:22'),(143,16,6,'2026-09-02','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(144,8,3,'2026-09-02','integral',190.00,'onibus',4.50,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(145,5,8,'2026-09-02','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(146,11,8,'2026-09-02','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(147,7,4,'2026-09-02','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(148,6,4,'2026-09-02','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(149,19,4,'2026-09-02','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(150,21,4,'2026-09-02','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(151,22,4,'2026-09-02','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-02 21:06:16','2026-09-02 21:06:16'),(152,16,4,'2026-09-04','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(153,8,3,'2026-09-04','integral',190.00,'onibus',4.50,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(154,5,8,'2026-09-04','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(155,11,8,'2026-09-04','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(156,23,4,'2026-09-04','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(157,18,8,'2026-09-04','integral',110.00,'onibus',4.50,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(158,7,4,'2026-09-04','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(159,6,3,'2026-09-04','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(160,19,4,'2026-09-04','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(161,21,4,'2026-09-04','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(162,22,4,'2026-09-04','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-04 00:43:24','2026-09-04 00:43:24'),(163,16,6,'2026-09-03','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(164,8,3,'2026-09-03','integral',190.00,'onibus',4.50,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(165,5,8,'2026-09-03','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(166,11,8,'2026-09-03','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(167,23,4,'2026-09-03','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(168,18,8,'2026-09-03','integral',110.00,'onibus',4.50,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(169,7,8,'2026-09-03','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(170,6,3,'2026-09-03','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(171,19,4,'2026-09-03','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(172,21,4,'2026-09-03','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(173,22,4,'2026-09-03','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-04 21:43:36','2026-09-04 21:43:36'),(174,16,6,'2026-09-08','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-09 08:55:55','2026-09-09 08:55:55'),(175,5,3,'2026-09-08','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-09 08:55:55','2026-09-09 08:55:55'),(176,18,4,'2026-09-08','integral',110.00,'onibus',4.50,NULL,3,'2026-09-09 08:55:55','2026-09-09 08:55:55'),(177,7,4,'2026-09-08','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-09 08:55:55','2026-09-09 08:55:55'),(178,6,3,'2026-09-08','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-09 08:55:55','2026-09-09 08:55:55'),(182,24,3,'2026-09-08','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-09 08:57:37','2026-09-09 08:57:37'),(183,16,6,'2026-09-09','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-09 20:44:51','2026-09-09 20:44:51'),(184,8,3,'2026-09-09','integral',190.00,'onibus',4.50,NULL,3,'2026-09-09 20:45:51','2026-09-09 20:45:51'),(185,5,2,'2026-09-09','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-09 20:45:51','2026-09-09 20:45:51'),(186,11,2,'2026-09-09','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-09 20:45:51','2026-09-09 20:45:51'),(187,18,4,'2026-09-09','integral',110.00,'onibus',4.50,NULL,3,'2026-09-09 20:45:51','2026-09-09 20:45:51'),(188,7,4,'2026-09-09','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-09 20:45:51','2026-09-09 20:45:51'),(189,6,3,'2026-09-09','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-09 20:45:51','2026-09-09 20:45:51'),(190,16,6,'2026-09-10','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:03:10','2026-09-11 21:03:10'),(191,8,3,'2026-09-10','integral',190.00,'onibus',4.50,NULL,3,'2026-09-11 21:03:10','2026-09-11 21:03:10'),(192,5,2,'2026-09-10','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-11 21:03:10','2026-09-11 21:03:10'),(193,11,2,'2026-09-10','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:03:10','2026-09-11 21:03:10'),(194,18,4,'2026-09-10','integral',110.00,'onibus',4.50,NULL,3,'2026-09-11 21:03:10','2026-09-11 21:03:10'),(195,7,4,'2026-09-10','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:03:10','2026-09-11 21:03:10'),(196,6,3,'2026-09-10','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-11 21:03:10','2026-09-11 21:03:10'),(197,22,2,'2026-09-10','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:03:10','2026-09-11 21:03:10'),(198,16,6,'2026-09-11','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:03:51','2026-09-11 21:03:51'),(199,8,3,'2026-09-11','integral',190.00,'onibus',4.50,NULL,3,'2026-09-11 21:03:51','2026-09-11 21:03:51'),(200,5,2,'2026-09-11','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-11 21:03:51','2026-09-11 21:03:51'),(201,11,2,'2026-09-11','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:03:51','2026-09-11 21:03:51'),(202,18,4,'2026-09-11','integral',110.00,'onibus',4.50,NULL,3,'2026-09-11 21:03:51','2026-09-11 21:03:51'),(203,7,4,'2026-09-11','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:03:51','2026-09-11 21:03:51'),(204,6,3,'2026-09-11','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-11 21:03:51','2026-09-11 21:03:51'),(205,22,2,'2026-09-11','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:03:51','2026-09-11 21:03:51'),(206,22,2,'2026-09-09','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:04:06','2026-09-11 21:04:06'),(207,25,2,'2026-09-08','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:17:00','2026-09-11 21:17:00'),(208,25,2,'2026-09-09','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:17:12','2026-09-11 21:17:12'),(209,25,2,'2026-09-10','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:17:20','2026-09-11 21:17:20'),(210,25,2,'2026-09-11','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-11 21:17:33','2026-09-11 21:17:33'),(211,16,6,'2026-09-14','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-15 21:18:51','2026-09-15 21:18:51'),(212,8,3,'2026-09-14','integral',190.00,'onibus',4.50,NULL,3,'2026-09-15 21:18:51','2026-09-15 21:18:51'),(213,5,2,'2026-09-14','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-15 21:18:51','2026-09-15 21:18:51'),(214,11,2,'2026-09-14','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-15 21:18:51','2026-09-15 21:18:51'),(215,25,2,'2026-09-14','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-15 21:18:51','2026-09-15 21:18:51'),(216,18,4,'2026-09-14','integral',110.00,'onibus',4.50,NULL,3,'2026-09-15 21:18:51','2026-09-15 21:18:51'),(217,7,4,'2026-09-14','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-15 21:18:51','2026-09-15 21:18:51'),(218,6,3,'2026-09-14','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-15 21:18:51','2026-09-15 21:18:51'),(219,16,2,'2026-09-15','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-15 21:19:29','2026-09-15 21:19:29'),(220,8,3,'2026-09-15','integral',190.00,'onibus',4.50,NULL,3,'2026-09-15 21:19:29','2026-09-15 21:19:29'),(221,5,2,'2026-09-15','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-15 21:19:29','2026-09-15 21:19:29'),(222,18,4,'2026-09-15','integral',110.00,'onibus',4.50,NULL,3,'2026-09-15 21:19:29','2026-09-15 21:19:29'),(223,7,4,'2026-09-15','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-15 21:19:29','2026-09-15 21:19:29'),(224,6,3,'2026-09-15','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-15 21:19:29','2026-09-15 21:19:29'),(226,22,2,'2026-09-15','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-15 21:19:43','2026-09-15 21:19:43'),(227,11,6,'2026-09-15','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-15 21:20:09','2026-09-15 21:20:09'),(228,16,6,'2026-09-16','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(229,8,3,'2026-09-16','integral',190.00,'onibus',4.50,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(230,5,2,'2026-09-16','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(231,11,6,'2026-09-16','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(232,25,2,'2026-09-16','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(233,18,4,'2026-09-16','integral',110.00,'onibus',4.50,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(234,7,4,'2026-09-16','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(235,6,3,'2026-09-16','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(236,22,2,'2026-09-16','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:56:28','2026-09-17 20:56:28'),(237,16,6,'2026-09-17','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(238,8,3,'2026-09-17','integral',190.00,'onibus',4.50,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(239,5,2,'2026-09-17','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(240,11,6,'2026-09-17','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(241,25,2,'2026-09-17','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(242,18,4,'2026-09-17','integral',110.00,'onibus',4.50,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(243,7,4,'2026-09-17','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(244,6,3,'2026-09-17','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(245,22,3,'2026-09-17','integral',150.00,'nenhuma',0.00,NULL,3,'2026-09-17 20:57:00','2026-09-17 20:57:00'),(246,16,6,'2026-09-18','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(248,8,3,'2026-09-18','integral',190.00,'onibus',4.50,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(249,5,3,'2026-09-18','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(250,11,6,'2026-09-18','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(251,23,3,'2026-09-18','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(252,25,6,'2026-09-18','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(253,18,4,'2026-09-18','integral',110.00,'onibus',4.50,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(254,7,4,'2026-09-18','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(255,6,3,'2026-09-18','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-18 21:25:34','2026-09-18 21:25:34'),(256,23,3,'2026-09-17','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-18 21:25:46','2026-09-18 21:25:46'),(257,23,3,'2026-09-16','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-18 21:25:53','2026-09-18 21:25:53'),(258,16,3,'2026-09-21','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-21 20:41:35','2026-09-21 20:41:35'),(259,5,3,'2026-09-21','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-21 20:41:35','2026-09-21 20:41:35'),(260,11,6,'2026-09-21','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-21 20:41:26','2026-09-21 20:41:26'),(261,23,3,'2026-09-21','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-21 20:41:26','2026-09-21 20:41:26'),(262,25,2,'2026-09-21','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-21 20:41:26','2026-09-21 20:41:26'),(263,18,3,'2026-09-21','integral',120.00,'onibus',4.50,NULL,3,'2026-09-21 20:41:26','2026-09-21 20:42:04'),(264,7,5,'2026-09-21','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-21 20:41:26','2026-09-21 20:41:26'),(265,6,3,'2026-09-21','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-21 20:41:26','2026-09-21 20:41:26'),(266,16,6,'2026-09-22','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(267,8,3,'2026-09-22','integral',190.00,'onibus',4.50,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(268,5,2,'2026-09-22','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(269,11,6,'2026-09-22','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(270,23,3,'2026-09-22','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(271,25,2,'2026-09-22','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(272,18,4,'2026-09-22','integral',120.00,'onibus',4.50,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(273,7,4,'2026-09-22','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(274,6,3,'2026-09-22','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-25 20:17:47','2026-09-25 20:17:47'),(275,16,6,'2026-09-23','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(276,8,3,'2026-09-23','integral',190.00,'onibus',4.50,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(277,5,2,'2026-09-23','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(278,11,6,'2026-09-23','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(279,23,3,'2026-09-23','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(280,25,6,'2026-09-23','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(281,18,8,'2026-09-23','integral',120.00,'onibus',4.50,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(282,7,4,'2026-09-23','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(283,6,3,'2026-09-23','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-25 20:19:48','2026-09-25 20:19:48'),(284,16,6,'2026-09-24','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(285,8,3,'2026-09-24','integral',190.00,'onibus',4.50,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(286,5,2,'2026-09-24','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(287,11,6,'2026-09-24','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(288,23,3,'2026-09-24','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(289,25,2,'2026-09-24','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(290,18,4,'2026-09-24','integral',120.00,'onibus',4.50,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(291,7,4,'2026-09-24','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(292,6,3,'2026-09-24','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-25 20:20:16','2026-09-25 20:20:16'),(293,16,6,'2026-09-25','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07'),(294,8,3,'2026-09-25','integral',190.00,'onibus',4.50,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07'),(295,5,2,'2026-09-25','integral',150.00,'gasolina',50.00,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07'),(296,11,6,'2026-09-25','integral',120.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07'),(297,23,3,'2026-09-25','integral',200.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07'),(298,25,2,'2026-09-25','integral',270.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07'),(299,18,4,'2026-09-25','integral',120.00,'onibus',4.50,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07'),(300,7,4,'2026-09-25','integral',250.00,'nenhuma',0.00,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07'),(301,6,3,'2026-09-25','integral',250.00,'gasolina',50.00,NULL,3,'2026-09-25 20:21:07','2026-09-25 20:21:07');
/*!40000 ALTER TABLE `presencas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('pZPxnpDobyHNKeQ6PzPWqOOUHtW8lMbqANiCFzvC',3,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','eyJfdG9rZW4iOiI2TDhsUnZVbnAySmJ5YklWU2FLY09wb2ZhTGhzc2x6b3p5aURNRHYxIiwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjMsIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC9sb2NhbGhvc3RcL3BlcmlvZG9zXC85Iiwicm91dGUiOiJwZXJpb2Rvcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1790369172),('yAXDgrbRW6l1KjSHc3GJEmRWE3OBnBZvcG0tUanF',3,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJDMTdJTWVlcWlUNDhGaWtjSXVJSFhLVmdxbjBkUk9rUXpON0NvSzAxIiwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjMsIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC9sb2NhbGhvc3RcL3BlcmlvZG9zXC85Iiwicm91dGUiOiJwZXJpb2Rvcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1790023326);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'Administrador','admin@controleobra.test','admin','2026-08-10 00:06:58','$2y$12$HRA645nFJAN8AZAoeYIBfOYVLBAUOkiUSoQ5Nb2FLcQzY4C3iJpoC','3X8YZ7GPdZrPTavzelz53d9njqQunJHC1D5meowS1HAZf1oNGBDzqYjrwGmD','2026-08-10 00:06:58','2026-08-10 00:06:58'),(4,'Ajudante','ajuda@controleobra.test','ajudante','2026-08-10 00:06:58','$2y$12$ceIta0H6YspJUVrdhRsYd.71VLBpaFGkcSCC.36KUuy..SaWBNXn2',NULL,'2026-08-10 00:06:58','2026-08-10 00:06:58');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-26 11:40:30
